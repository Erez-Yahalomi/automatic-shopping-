# Annotated Smart-Shelf Weight Event Detector

This package contains the annotated detector, the expanded regression tests, the three CSV recordings, and Windows batch files for one-command execution.

## Requirements

Install and start Docker Desktop on Windows 11. No separate Python or Python-library installation is required on Windows.

## Package contents

- `weight_event_detector_annotated.py` — detector with detailed algorithm explanations and labeled text-result output.
- `test_weight_event_detector.py` — normal and edge-case tests for the annotated detector.
- `data/50_gr.csv`, `data/500_gr.csv`, `data/1000_gr.csv` — supplied recordings.
- `run_annotated.bat` — builds the image and runs the annotated detector in one command.
- `run_tests.bat` — builds the image and runs the complete test suite in one command.
- `Dockerfile` and `requirements.txt` — image setup and Python dependency configuration.

## Run the annotated detector

Start Docker Desktop, then open the project folder and double-click:

```text
run_annotated.bat
```

Or run it from PowerShell:

```powershell
.\run_annotated.bat
```

The detector analyzes all three CSV files, prints the detected events, and saves plots and clearly labeled text results in the `results` folder. The text files contain the weight change, event time, and meaning of each event.

## Run all tests

Double-click:

```text
run_tests.bat
```

Or run:

```powershell
.\run_tests.bat
```

The test launcher builds the image and runs the complete 13-test suite. A successful run ends with `OK`.

## Modify the software

Edit `weight_event_detector_annotated.py` in this folder with a text editor. After saving changes, run `run_annotated.bat` again. The image is rebuilt automatically, so the new code is included in the next run.

If you change the detector behavior, run `run_tests.bat` to check whether the expected results still pass.

## Output files

The `results` folder is created automatically. The detector writes PNG plots and text files containing numerical results. Existing files with the same names are replaced on the next run.
